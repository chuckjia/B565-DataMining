# Generate Binary Mask Files from Encoded CSV files

In this folder, the scripts and functions are implemented in R.

To generate single cell masks from the ground truth file for the test data set, use the R function `createMaskFromGroundTruth` from the R file of the same name.

To generate single cell masks from the ground truth file for the test data set, use the R function `createMaskFromEncodedFile` from the R file of the same name.


Some examples are provided in the file `Eg1.R`.
