# M565 Final Project

In this project:

  `evaluation` folder contains MATLAB functions and scripts that computes accuracy of predictions.
  
  `img_proc` folder contains R functions that processes image data.
  
  `unet` folder contains Python scripts that implements the U-Net structure for predictions.
