% Create single masks

outerFolder = '/Users/chuckjia/Documents/Workspace/DataStorage/B565/stage1_train';
createSingleMasks(outerFolder)

