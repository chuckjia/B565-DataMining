# M565 Final Project

In this project:

  `chuck` folder contains scripts and functions on U-net and evaluation. Code is implemented using Python, MATLAB, and R.
  
  `Ruiyu` folder contains code that implements the SVM approach. Code is written in MATLAB.
  
  `Yining` folder contains scripts and functions that implements the segmentation method. Code is written in MATLAB.
